
public interface Usuario {

    String getLogin();

    String getPassword();
}
